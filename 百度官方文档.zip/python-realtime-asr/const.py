# -*- coding: utf-8 -*-
"""
常量
"""

# 下面2个是鉴权信息
APPID = 10000000

APPKEY = "g8eBUMSxxxxxgxLFYviL"

# 语言模型 ， 可以修改为其它语言模型测试，如远场普通话19362
DEV_PID = 15372

# 可以改为wss://
URI = "ws://vop.baidu.com/realtime_asr"
